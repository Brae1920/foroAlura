package co.com.alura.jpa.respuestas;

public record DatosCrearRespuesta(String mensaje, Long idTopico, Long idAutor) {
}
