package co.com.alura.jpa.respuestas;

public record DatosEditarRespuesta(String mensaje, Long idAutor) {
}
