package co.com.alura.jpa.topicos;


import co.com.alura.jpa.respuestas.DatosRespuesta;

public record EstadoTopicoRespuesta(DatosTopico topico, DatosRespuesta respuesta) {
}
