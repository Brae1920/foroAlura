package co.com.alura.jpa.curso.validaciones;

import co.com.alura.jpa.curso.DatosCrearCurso;

public interface ValidadorCurso {
    public void validar(DatosCrearCurso datos);
}
