package co.com.alura.jpa.curso;

public enum Categoria {
    FRONT_END,
    BACK_END,
    FULL_STACK,
    DATA_ANALYTICS,
    IA
}
