package co.com.alura.jpa.topicos.validaciones;

import co.com.alura.jpa.topicos.DatosCrearTopico;

public interface ValidadorTopico {
    public void validar(DatosCrearTopico datos);
}
