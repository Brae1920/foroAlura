package co.com.alura.jpa.respuestas.validaciones;

import co.com.alura.jpa.respuestas.DatosCrearRespuesta;

public interface ValidadorRespuesta {
    public void validar(DatosCrearRespuesta datos);
}
