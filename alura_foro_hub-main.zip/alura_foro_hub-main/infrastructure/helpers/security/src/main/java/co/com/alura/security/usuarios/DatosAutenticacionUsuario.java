package co.com.alura.security.usuarios;

public record DatosAutenticacionUsuario(String email, String contrasenia) {
}
