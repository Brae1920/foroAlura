package co.com.alura.security;

public record DatosJWTToken(String jwTtoken) {
}
